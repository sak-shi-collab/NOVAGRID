from django import forms

from .models import ResearchPaper


class PaperUploadForm(forms.ModelForm):
    keywords = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'field-input', 'placeholder': 'transformers, robotics, ...'}))

    class Meta:
        model = ResearchPaper
        fields = ('title', 'authors', 'abstract', 'keywords', 'source_url', 'file')
        widgets = {
            'title': forms.TextInput(attrs={'class': 'field-input'}),
            'authors': forms.TextInput(attrs={'class': 'field-input'}),
            'abstract': forms.Textarea(attrs={'class': 'field-input textarea', 'rows': 5}),
            'source_url': forms.URLInput(attrs={'class': 'field-input'}),
            'file': forms.ClearableFileInput(attrs={'class': 'field-input'}),
        }

    def clean_keywords(self):
        raw_keywords = self.cleaned_data.get('keywords', '')
        if not raw_keywords:
            return []
        return [item.strip() for item in raw_keywords.split(',') if item.strip()]

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.keywords = self.cleaned_data.get('keywords', [])
        if commit:
            instance.save()
        return instance

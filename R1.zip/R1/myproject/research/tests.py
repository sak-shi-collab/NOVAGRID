from django.contrib.auth import get_user_model
from django.test import TestCase

from .models import AnalysisJob, ResearchPaper


class ResearchAppTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username='researcher', password='strongpass123')

    def test_paper_creation_and_job_tracking(self):
        paper = ResearchPaper.objects.create(
            title='Attention Is All You Need',
            slug='attention-is-all-you-need',
            owner=self.user,
            abstract='A transformer model for sequence-to-sequence learning.',
            status='draft',
        )
        job = AnalysisJob.objects.create(
            paper=paper,
            owner=self.user,
            status='queued',
            external_job_id='ext-123',
            progress=0,
        )

        self.assertEqual(paper.owner, self.user)
        self.assertEqual(job.paper, paper)
        self.assertEqual(paper.status, 'draft')
        self.assertEqual(job.status, 'queued')

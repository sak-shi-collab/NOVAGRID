from django.urls import path

from . import views

urlpatterns = [
    path('', views.research_dashboard, name='research_dashboard'),
    path('upload/', views.upload_paper, name='upload_paper'),
    path('library/', views.paper_library, name='paper_library'),
    path('analyzer/', views.paper_analyzer, name='paper_analyzer'),
    path('analyzer/<slug:slug>/', views.paper_analyzer, name='paper_analyzer_detail'),
    path('gap-mapper/', views.gap_mapper, name='gap_mapper'),
]

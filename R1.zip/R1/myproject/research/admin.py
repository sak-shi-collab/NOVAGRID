from django.contrib import admin

from .models import AnalysisJob, PaperAnalysis, PaperComparison, PaperEmbedding, ResearchPaper


@admin.register(ResearchPaper)
class ResearchPaperAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'status', 'created_at')
    search_fields = ('title', 'authors', 'owner__username')
    list_filter = ('status', 'created_at')


@admin.register(PaperAnalysis)
class PaperAnalysisAdmin(admin.ModelAdmin):
    list_display = ('paper', 'created_at')
    search_fields = ('paper__title', 'research_objectives')


@admin.register(PaperEmbedding)
class PaperEmbeddingAdmin(admin.ModelAdmin):
    list_display = ('paper', 'model_name', 'embedding_kind', 'created_at')


@admin.register(PaperComparison)
class PaperComparisonAdmin(admin.ModelAdmin):
    list_display = ('first_paper', 'second_paper', 'owner', 'created_at')


@admin.register(AnalysisJob)
class AnalysisJobAdmin(admin.ModelAdmin):
    list_display = ('paper', 'owner', 'status', 'progress', 'created_at')
    list_filter = ('status', 'created_at')

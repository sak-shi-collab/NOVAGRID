from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.utils.text import slugify

from .forms import PaperUploadForm
from .models import AnalysisJob, PaperAnalysis, PaperComparison, ResearchPaper


@login_required
def research_dashboard(request):
    papers = ResearchPaper.objects.filter(owner=request.user).order_by('-updated_at')[:5]
    jobs = AnalysisJob.objects.filter(owner=request.user).order_by('-updated_at')[:5]
    return render(request, 'research/dashboard.html', {'papers': papers, 'jobs': jobs})


@login_required
def upload_paper(request):
    if request.method == 'POST':
        form = PaperUploadForm(request.POST, request.FILES)
        if form.is_valid():
            paper = form.save(commit=False)
            paper.owner = request.user
            paper.title = paper.title.strip()
            base_slug = slugify(paper.title) or 'untitled-paper'
            slug = base_slug
            counter = 1
            while ResearchPaper.objects.filter(slug=slug).exists():
                slug = f'{base_slug}-{counter}'
                counter += 1
            paper.slug = slug
            paper.status = 'queued'
            paper.save()
            AnalysisJob.objects.create(
                paper=paper,
                owner=request.user,
                status='queued',
                progress=10,
                result_summary='Uploaded and queued for analysis.'
            )
            messages.success(request, 'Paper uploaded and queued for processing.')
            return redirect('paper_analyzer_detail', slug=paper.slug)
    else:
        form = PaperUploadForm()
    return render(request, 'research/upload_paper.html', {'form': form})


@login_required
def paper_library(request):
    papers = ResearchPaper.objects.filter(owner=request.user).order_by('-updated_at')
    return render(request, 'research/paper_library.html', {'papers': papers})


@login_required
def paper_analyzer(request, slug=None):
    paper = None
    if slug:
        paper = ResearchPaper.objects.filter(owner=request.user, slug=slug).first()
    if paper is None:
        paper = ResearchPaper.objects.filter(owner=request.user).order_by('-updated_at').first()

    analysis = PaperAnalysis.objects.filter(paper=paper).order_by('-created_at').first() if paper else None
    return render(request, 'research/paper_analyzer.html', {'paper': paper, 'analysis': analysis})


@login_required
def gap_mapper(request):
    papers = ResearchPaper.objects.filter(owner=request.user).order_by('-updated_at')
    selected = request.GET.getlist('paper')
    comparison = None

    if len(selected) >= 2:
        chosen = list(ResearchPaper.objects.filter(owner=request.user, id__in=selected)[:2])
        if len(chosen) == 2:
            summary = (
                f'{chosen[0].title} and {chosen[1].title} highlight complementary but non-overlapping research trajectories. '
                'The comparison suggests a gap around evaluation rigor, dataset diversity, and cross-domain generalization.'
            )
            comparison = {
                'summary': summary,
                'gaps': [
                    'Need for broader and more diverse benchmarking conditions.',
                    'Limited evaluation across underrepresented datasets and deployment settings.',
                    'Unclear generalization across interdisciplinary research tasks.'
                ],
                'references': [chosen[0].title, chosen[1].title],
                'papers': chosen,
            }
    return render(request, 'research/gap_mapper.html', {'papers': papers, 'comparison': comparison})

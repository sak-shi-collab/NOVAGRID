from django.conf import settings
from django.db import models


class ResearchPaper(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('queued', 'Queued'),
        ('processing', 'Processing'),
        ('analyzed', 'Analyzed'),
        ('archived', 'Archived'),
    ]

    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='research_papers')
    authors = models.CharField(max_length=255, blank=True, default='')
    abstract = models.TextField(blank=True)
    keywords = models.JSONField(default=list, blank=True)
    file = models.FileField(upload_to='research/papers/', blank=True, null=True)
    source_url = models.URLField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    publication_year = models.PositiveIntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return self.title


class PaperAnalysis(models.Model):
    paper = models.ForeignKey(ResearchPaper, on_delete=models.CASCADE, related_name='analysis_records')
    research_objectives = models.TextField(blank=True)
    methodology = models.TextField(blank=True)
    results = models.TextField(blank=True)
    datasets = models.TextField(blank=True)
    limitations = models.TextField(blank=True)
    future_directions = models.TextField(blank=True)
    references = models.JSONField(default=list, blank=True)
    evidence_passages = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Analysis for {self.paper.title}'


class PaperEmbedding(models.Model):
    paper = models.ForeignKey(ResearchPaper, on_delete=models.CASCADE, related_name='embeddings')
    model_name = models.CharField(max_length=255, default='sentence-transformers/all-MiniLM-L6-v2')
    embedding_kind = models.CharField(max_length=50, default='semantic')
    vector_store_ref = models.CharField(max_length=255, blank=True, default='')
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.paper.title} ({self.embedding_kind})'


class PaperComparison(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='paper_comparisons')
    first_paper = models.ForeignKey(ResearchPaper, on_delete=models.CASCADE, related_name='comparisons_as_first')
    second_paper = models.ForeignKey(ResearchPaper, on_delete=models.CASCADE, related_name='comparisons_as_second')
    summary = models.TextField(blank=True)
    gap_hypotheses = models.JSONField(default=list, blank=True)
    evidence = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.first_paper.title} vs {self.second_paper.title}'


class AnalysisJob(models.Model):
    STATUS_CHOICES = [
        ('queued', 'Queued'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]

    paper = models.ForeignKey(ResearchPaper, on_delete=models.CASCADE, related_name='analysis_jobs')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='analysis_jobs')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='queued')
    external_job_id = models.CharField(max_length=255, blank=True, default='')
    progress = models.PositiveIntegerField(default=0)
    result_summary = models.TextField(blank=True)
    error_message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f'{self.paper.title} - {self.status}'

const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');

const nodes = [];
const maxNodes = 48;

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

function createNode() {
    return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.7,
        vy: (Math.random() - 0.5) * 0.7,
        radius: Math.random() * 2.6 + 1.1,
        hue: Math.random() > 0.6 ? 190 : 245
    };
}

function initNodes() {
    nodes.length = 0;
    for (let i = 0; i < maxNodes; i++) {
        nodes.push(createNode());
    }
}

function connectNodes() {
    for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
            const b = nodes[j];
            const dx = a.x - b.x;
            const dy = a.y - b.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 160) {
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.lineTo(b.x, b.y);
                ctx.strokeStyle = `rgba(120, 200, 255, ${0.12 + (1 - dist / 160) * 0.35})`;
                ctx.lineWidth = 1;
                ctx.stroke();
            }
        }
    }
}

function updateNodes() {
    nodes.forEach((node) => {
        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;
    });
}

function drawBackground() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const gradient = ctx.createRadialGradient(
        canvas.width * 0.5,
        canvas.height * 0.35,
        40,
        canvas.width * 0.5,
        canvas.height * 0.5,
        canvas.width * 0.78
    );
    gradient.addColorStop(0, 'rgba(45, 78, 140, 0.24)');
    gradient.addColorStop(0.4, 'rgba(11, 16, 30, 0.12)');
    gradient.addColorStop(1, 'rgba(2, 4, 9, 0.0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    nodes.forEach((node) => {
        ctx.beginPath();
        ctx.fillStyle = `hsla(${node.hue}, 85%, 68%, 0.9)`;
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        ctx.fill();
    });

    connectNodes();
}

function animate() {
    updateNodes();
    drawBackground();
    requestAnimationFrame(animate);
}

window.addEventListener('resize', () => {
    resizeCanvas();
    initNodes();
});

resizeCanvas();
initNodes();
animate();

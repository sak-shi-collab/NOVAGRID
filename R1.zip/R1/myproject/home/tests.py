from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class NovaGridFlowTests(TestCase):
    def test_home_page_loads(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

    def test_user_can_sign_up(self):
        response = self.client.post(
            reverse('signup'),
            {
                'full_name': 'Dr. Maya Singh',
                'username': 'maysingh',
                'email': 'maya@example.com',
                'password1': 'StrongPass123!',
                'password2': 'StrongPass123!',
                'discipline': 'Neuroscience',
                'location': 'London',
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(get_user_model().objects.filter(username='maysingh').exists())

    def test_dashboard_requires_login(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)

    def test_room_message_post_creates_thread_entry(self):
        user = get_user_model().objects.create_user(username='collabuser', password='StrongPass123!')
        self.client.login(username='collabuser', password='StrongPass123!')
        room = user.owned_rooms.create(
            name='Signal Lab',
            slug='signal-lab',
            description='Testing collaborative updates.',
            is_private=False,
        )

        response = self.client.post(
            reverse('room', args=['signal-lab']),
            {'message': 'I have the imaging dataset ready for review.'},
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'I have the imaging dataset ready for review.')

from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render

from .forms import SignupForm
from .models import ResearcherProfile, ResearchRoom


User = get_user_model()


def seed_demo_data():
    if not ResearcherProfile.objects.exists():
        profiles = [
            ('Ava Chen', 'Neuroscience', 'Singapore', 'Memory systems and adaptive intelligence.'),
            ('Mateo Silva', 'Robotics', 'São Paulo', 'Embodied robotics and human-robot collaboration.'),
            ('Nora Ibrahim', 'AI Research', 'Dubai', 'Machine learning systems for scientific reasoning.'),
            ('Leo Hart', 'Platform Ops', 'Berlin', 'Distributed systems for secure global research workspaces.'),
        ]
        for name, discipline, location, bio in profiles:
            username = name.lower().replace(' ', '')
            user, _ = User.objects.get_or_create(username=username, defaults={'email': f'{username}@example.com'})
            if not user.email:
                user.email = f'{username}@example.com'
                user.save()
            ResearcherProfile.objects.get_or_create(
                user=user,
                defaults={'full_name': name, 'discipline': discipline, 'location': location, 'bio': bio, 'is_verified': True},
            )

    if not ResearchRoom.objects.exists():
        owner, _ = User.objects.get_or_create(username='novaadmin', defaults={'email': 'novaadmin@example.com'})
        rooms = [
            ('Brain-to-Robot Lab', 'brain-to-robot-lab', 'Exploring memory architectures and adaptive robotics through human-centered AI.', True),
            ('Missing Link Studio', 'missing-link-studio', 'Mapping cross-discipline research gaps between neuroscience, reinforcement learning, and cognition.', False),
        ]
        for name, slug, description, is_private in rooms:
            ResearchRoom.objects.get_or_create(
                slug=slug,
                defaults={'name': name, 'owner': owner, 'description': description, 'is_private': is_private},
            )


def home(request):
    seed_demo_data()
    profiles = ResearcherProfile.objects.select_related('user').order_by('-is_verified')[:6]
    rooms = ResearchRoom.objects.select_related('owner').prefetch_related('members')[:3]
    people = [
        {"name": "Ava Chen", "role": "Product Lead", "location": "Singapore", "status": "Live"},
        {"name": "Mateo Silva", "role": "Design Systems", "location": "São Paulo", "status": "Syncing"},
        {"name": "Nora Ibrahim", "role": "AI Research", "location": "Dubai", "status": "Reviewing"},
        {"name": "Leo Hart", "role": "Platform Ops", "location": "Berlin", "status": "Online"},
        {"name": "Priya Nair", "role": "Community", "location": "Toronto", "status": "Live"},
        {"name": "Samir Okafor", "role": "Growth", "location": "Lagos", "status": "Connecting"},
    ]

    stats = [
        {"label": "Global nodes", "value": "128K"},
        {"label": "Active rooms", "value": "84"},
        {"label": "Avg. latency", "value": "21ms"},
    ]

    return render(request, 'home/index.html', {'people': people, 'stats': stats, 'profiles': profiles, 'rooms': rooms})


def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            ResearcherProfile.objects.create(
                user=user,
                full_name=form.cleaned_data['full_name'],
                discipline=form.cleaned_data['discipline'],
                location=form.cleaned_data['location'],
                bio=form.cleaned_data.get('bio', ''),
            )
            authenticated_user = authenticate(username=user.username, password=form.cleaned_data['password1'])
            if authenticated_user is not None:
                login(request, authenticated_user)
            messages.success(request, 'Your NovaGrid account is ready. Welcome aboard.')
            return redirect('dashboard')
    else:
        form = SignupForm()
    return render(request, 'home/signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.username}.')
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'home/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.info(request, 'You have been signed out.')
    return redirect('home')


@login_required
def dashboard(request):
    seed_demo_data()
    profiles = ResearcherProfile.objects.select_related('user').order_by('-is_verified', 'user__username')[:8]
    rooms = ResearchRoom.objects.select_related('owner').prefetch_related('members')[:5]
    return render(request, 'home/dashboard.html', {'profiles': profiles, 'rooms': rooms})


@login_required
def discover(request):
    seed_demo_data()
    profiles = ResearcherProfile.objects.select_related('user').order_by('-is_verified', 'user__username')
    return render(request, 'home/discover.html', {'profiles': profiles})


@login_required
def room_view(request, slug):
    seed_demo_data()
    room = ResearchRoom.objects.select_related('owner').prefetch_related('members').get(slug=slug)
    room_messages = room.messages.select_related('sender').all()

    if request.method == 'POST':
        if request.user not in room.members.all():
            room.members.add(request.user)
            messages.success(request, f'You joined {room.name}.')

        message = (request.POST.get('message') or '').strip()
        if message:
            room.messages.create(sender=request.user, content=message)
            messages.success(request, 'Your update was shared with the room.')

    room_messages = room.messages.select_related('sender').all()
    return render(request, 'home/room.html', {'room': room, 'messages': room_messages})
